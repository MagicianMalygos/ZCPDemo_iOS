//
//  MyCell.m
//  Demo
//
//  Created by 朱超鹏(外包) on 16/12/29.
//  Copyright © 2016年 zcp. All rights reserved.
//

#import "MyCell.h"

@interface MyCell ()

@property (nonatomic, strong) NSDictionary *configInfo;

@end

@implementation MyCell

- (void)configWithDict:(NSDictionary *)dict {
    self.configInfo = dict;
    NSArray *cate_data = [dict objectForKey:@"cate_data"];
    
    for (NSDictionary *dict in cate_data) {
        UIButton *button  = [UIButton buttonWithType:UIButtonTypeCustom];
        NSUInteger index = [cate_data indexOfObject:dict];
        button.frame = CGRectMake(index * 40, 0, 70, 20);
        button.tag = index;
        button.backgroundColor = [UIColor redColor];
        [button setTitle:[dict objectForKey:@"cate_name"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
    }
}

- (void)clickButton:(UIButton *)button {
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickButton:aboutInfo:)]) {
        NSDictionary *changtiaoInfo = [self.configInfo objectForKey:@"cate_data"][button.tag];
        [self.delegate clickButton:button aboutInfo:changtiaoInfo];
    }
}

@end
