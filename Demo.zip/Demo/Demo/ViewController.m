//
//  ViewController.m
//  Demo
//
//  Created by 朱超鹏(外包) on 16/12/29.
//  Copyright © 2016年 zcp. All rights reserved.
//

#import "ViewController.h"
#import "MyCell.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate, CellDelegate>

@property (nonatomic, strong) NSDictionary *dict;
@property (nonatomic, strong) UITableView *tb;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 假设网络请求得到了一组数据
    self.dict = @{@"status": @(1),
                  @"info": @"获取成功",
                  @"data":@[
                      @{@"qid":@"23",
                        @"week":@"五",
                        @"cate_data": @[
                                @{@"changtiao_id":@"1",@"cate_name":@"七星彩"},
                                @{@"changtiao_id":@"2",@"cate_name":@"808"},
                                @{@"changtiao_id":@"3",@"cate_name":@"444"}
                        ]
                        },
                      @{@"qid":@"22",
                        @"week":@"六",
                        @"cate_data": @[
                                @{@"changtiao_id":@"4",@"cate_name":@"七星彩"},
                                @{@"changtiao_id":@"5",@"cate_name":@"808"},
                                @{@"changtiao_id":@"6",@"cate_name":@"444"}
                                ]
                        },
                      ]
                  };
    
    [self.view addSubview:self.tb];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[self.dict objectForKey:@"data"] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"cell";
    MyCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[MyCell alloc] init];
    }
    [cell configWithDict:[self.dict objectForKey:@"data"][indexPath.row]];
    cell.delegate = self;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40;
}

#pragma mark - CellDelegate

- (void)clickButton:(UIButton *)button aboutInfo:(NSDictionary *)dict {
    NSString *changtiao_id = [dict objectForKey:@"changtiao_id"];
    NSLog(@"%@", changtiao_id);
}


#pragma mark - getter / setter
- (UITableView *)tb {
    if (!_tb) {
        _tb = [[UITableView alloc] initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height - 20)];
        _tb.dataSource = self;
        _tb.delegate = self;
    }
    return _tb;
}

@end
