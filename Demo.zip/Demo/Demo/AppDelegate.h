//
//  AppDelegate.h
//  Demo
//
//  Created by 朱超鹏(外包) on 16/12/29.
//  Copyright © 2016年 zcp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

