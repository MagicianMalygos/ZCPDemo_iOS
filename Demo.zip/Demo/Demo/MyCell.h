//
//  MyCell.h
//  Demo
//
//  Created by 朱超鹏(外包) on 16/12/29.
//  Copyright © 2016年 zcp. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol CellDelegate <NSObject>

- (void)clickButton:(UIButton *)button aboutInfo:(NSDictionary *)dict;

@end

@interface MyCell : UITableViewCell

@property (nonatomic, weak) id<CellDelegate> delegate;

- (void)configWithDict:(NSDictionary *)dict;

@end
